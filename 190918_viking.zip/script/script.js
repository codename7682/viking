$(document).ready(function(){
    
    var speed = 1000; // 바이킹 한번 흔드는 시간
    var angle = 60;   // 바이킹 올리는 각도
    var times = 3;    // 바이킹 흔드는 횟수
    
    var cur = 0;
    function swing(){
        cur++;
        $("#ship").animate({
            dummy: angle
        },{
            duration: speed,
            easing: "swing",
            step: function(now,fx){
                $(this).css("transform","rotate(" + now + "deg)");   
            }
        });
        
        $("#ship").animate({
            dummy: -1*angle
        },{
            duration: speed,
            easing: "swing",
            step: function(now,fx){
                $(this).css("transform","rotate("+now+"deg)");
            }
        });
        
        if(cur >= times){
            $("#ship").animate({
                dummy:0
            },{
                duration: speed+300,
                easing: "swing",
                step: function(now,fx){
                    $(this).css("transform","rotate("+now+"deg)");
                },
                complete: function(){
                    cur = 0;
                }
            });
        }
    }
    
    $("#viking").click(function(){
        // 현재 #swing이 움직이고 있지 않다면
        // 정해진 횟수대로 swing을 시작하자.
        if(cur == 0){
            for(i=0; i<times; i++){
                swing();
            }
        }
    });
    
    var dropping = false;
    function drop(){
        dropping = true;
        $("#drop").animate({bottom: "185px"},10000);
        $("#drop").delay(3000).animate({bottom: "30px"},500);
        $("#drop").animate({
            bottom: "0px"
        },1500,"linear",function(){
            dropping = false;
        });
    }
    
    $("#gyro").click(function(){
        if(!dropping){
            drop();
        }
    });
    
    
    var cabinlen = 12;
    var cangle = 360 / cabinlen;
    var radius = 108;
    
    function deg2rad(deg){
        var result = deg * Math.PI / 180;
        return result;
    }
    
    for(i=0; i<cabinlen; i++){
        $("#wheel").append("<img class='cabin' src='images/cabin.png' />");      
        var x = radius * Math.cos(deg2rad(cangle*i));
        var y = radius * Math.sin(deg2rad(cangle*i));
        $(".cabin:last-of-type").css({
            marginLeft: x+"px",
            marginTop : y+"px"
        });
    }
    
    var dur = 20000;
    
    function rot(){
        $("#wheel").animate({
            dummy: 360
        },{
            duration: dur,
            easing: "linear",
            step: function(now,fx){
                $(this).css("transform","rotate("+now+"deg)");       
            },
            complete: function(){
                $(this).css({
                    dummy: 0,
                    transform: "rotate(0deg)"
                });
                rot();
            }
        });
        $(".cabin").animate({
            dummy: -360
        },{
            duration: dur,
            easing: "linear",
            step: function(now,fx){
                $(this).css("transform","translate(-50%,-50%) rotate("+now+"deg)");
            },
            complete: function(){
                $(this).css({
                    dummy: 0,
                    transform: "translate(-50%,-50%) rotate(0deg)"
                });
            }
        });
    };
    
    rot();
    
    // #gyrostop이 눌리면
        // #drop을 멈춘다.()
    
    $("#gyrostop").click(function(){
        $("#drop").queue(function(){
            $("#drop").css("filter","brigtness(5)");
            $("#drop").dequeue();
        });
    });
    
});


















